# uRAD-firmware
This Respository Write the firmware for reading RAW RADAR data from uRAD RADAR System.
## Introduction
RADAR (Radio Rangind And Detection) is an electronic device that transmits high energy electromagnetic waves and listens from the reflected waves from targets. With with reflect waves, information abou the target such as its distance from RADAR, its speed relative to RADAR, and its cross-sectional area of the target can be estimated. This project focus on low-cost,high-performance uRAD RADAR system. The goal of this project is to develop a script that can be used to interface with uRAD using the firmware library provided by the uRAD manufacturer.

## The uRAD system
For detailed description of how the uRAD system work, what parameters are configurable and what data can be recorded fromthe uRAD, it is advisable to consult the uRAD  manual directly. 
## Required Software
This library only requires Python3 and pip. All other dependancies will be installed during installation.
## How to install
open terminal and type: pip install urad-firmware
