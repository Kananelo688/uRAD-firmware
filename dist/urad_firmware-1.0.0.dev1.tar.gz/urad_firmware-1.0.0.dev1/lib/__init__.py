
__author__ = 'Kananelo Chabeli'
__license__ = 'MIT'
__description__ = 'The uRAD firmware library customized to extract only the raw RADAR data from uRAD RADAR system. Developed to run across all platforms.'
__version__= '1.0.0'