# uRAD-firmware
This Respository Write the firmware for reading RAW RADAR data from uRAD RADAR System.
